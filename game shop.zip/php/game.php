<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        Document
    </title>
    <link rel="stylesheet" href="../css/game.css">
</head>

<body>
    <?php include 'navbar.php'; ?>
        <div class="gamelist">
            <div class="game"><img src="../image/image10.jpg" alt="Game 1 Image">
                <div class="game-info">
                    <h3>Game 1 Title</h3>
                </div>
                <div class="game"><img src="../image/image4.jpg" alt="Game 1 Image">
                    <div class="game-info">
                        <h3>Game 2 Title</h3>
                    </div>
                    <div class="game"><img src="../image/image3.jpg" alt="Game 1 Image">
                        <div class="game-info">
                            <h3>Game 3 Title</h3>
                        </div>
                        <div class="game"><img src="../image/image5.jpg" alt="Game 1 Image">
                            <div class="game-info">
                                <h3>Game 4 Title</h3>
                            </div>
                            <div class="game"><img src="../image/image7.jpg" alt="Game 1 Image">
                                <div class="game-info">
                                    <h3>Game 5 Title</h3>
                                </div>
                            </div>
                        </div>