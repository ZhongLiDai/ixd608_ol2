<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>
    
</body>
</html>
<div class="nav">
    <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="game.php">Game</a></li>
        <li><a href="cart.php">Cart</a></li>
        <li><a href="aboutus.php">About us</a></li>
    </ul>
</div>

     <style> 

.navbar ul li {
    margin-left: 50px;
    margin-top: 8px;
}

.navbar {
    box-shadow: 10px 3px 3px rgba(0, 0, 0, 0.144);
    width: 100%;
    height: 50px;
    list-style: none;
    display: flex;
}
    </style>
    
</div>
    
</body>