<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        Document
    </title>
    <link rel="stylesheet" href="../css/cart.css">
</head>

<body>
    <?php include 'navbar.php'; ?>
        <div class="img"></div>
        <h1>Price:15$</h1>
        <button class="button">Buy and pay</button>
    </div>